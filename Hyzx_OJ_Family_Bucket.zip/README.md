# Hyzx_OJ_Family_Bucket
黄岩中学OJ全家桶

运行这些爬虫需要你下载requests库

OJ_img_Spider允许你爬取用户头像，保存在img文件夹下

OJ_User_Database和OJ_User_Folder允许你保存用户的profile,包括mood name majors等信息，如名字所示，这两个爬虫会以不同的方式保存数据

OJ_Code_Spider使用阉割版的模拟登录来抓取用户公开的代码，你可以在code文件夹里找到当时我们保存的代码(真的千奇百怪....)总共五百二十几个,我们选取了最大的前九十几个文件

新OJ用户数据允许你爬取新OJ用户基本数据和格言

祝你使用愉快:)

